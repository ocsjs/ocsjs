function n(a,r){for(var t=Object.assign({},a),o=0;o<r.length;o+=1){var e=r[o];delete t[e]}return t}export{n as o};
